
# FullCalendar Time Grid Plugin

Display your events on a grid of time slots

[View the docs &raquo;](https://fullcalendar.io/docs/timegrid-view)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
